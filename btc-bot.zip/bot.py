from flask import Flask, request, jsonify
import requests
import hmac
import hashlib
import time
import json

app = Flask(__name__)

# ========== OKX API KEYS ==========
API_KEY = "YOUR_OKX_API_KEY"
API_SECRET = "YOUR_OKX_SECRET"
PASSPHRASE = "YOUR_OKX_PASSPHRASE"
BASE_URL = "https://www.okx.com"

# ========== HELPERS ==========
def generate_signature(timestamp, method, request_path, body=""):
    message = f"{timestamp}{method}{request_path}{body}"
    signature = hmac.new(bytes(API_SECRET, encoding='utf-8'),
                         bytes(message, encoding='utf-8'), hashlib.sha256).digest()
    return signature.hex()

def send_okx_order(signal, entry, sl, tp1, tp2):
    side = "buy" if signal == "LONG" else "sell"

    timestamp = str(time.time())
    request_path = "/api/v5/trade/order"
    url = BASE_URL + request_path

    body = {
        "instId": "BTC-USDT-SWAP",
        "tdMode": "isolated",
        "side": side,
        "ordType": "market",
        "sz": "0.01",
        "clOrdId": f"auto_{int(time.time())}"
    }

    headers = {
        "OK-ACCESS-KEY": API_KEY,
        "OK-ACCESS-SIGN": generate_signature(timestamp, "POST", request_path, json.dumps(body)),
        "OK-ACCESS-TIMESTAMP": timestamp,
        "OK-ACCESS-PASSPHRASE": PASSPHRASE,
        "Content-Type": "application/json"
    }

    res = requests.post(url, headers=headers, json=body)
    return res.json()

@app.route('/webhook', methods=['POST'])
def webhook():
    data = request.get_json()
    try:
        signal = data["signal"]
        entry = float(data["entry"])
        sl = float(data["sl"])
        tp1 = float(data["tp1"])
        tp2 = float(data["tp2"])
        
        result = send_okx_order(signal, entry, sl, tp1, tp2)
        return jsonify({"status": "Order sent", "okx_response": result})
    
    except Exception as e:
        return jsonify({"error": str(e)}), 400

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=10000)
